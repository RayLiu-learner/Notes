# NBA Win Probabilities

This directory contains the data behind the story [Every NBA Team’s Chance Of Winning In Every Minute Across Every Game](https://fivethirtyeight.com/features/every-nba-teams-chance-of-winning-in-every-minute-across-every-game/).

`nba.tsv` contains the 2014-15 NBA season win probabilities for each team over the course of a game, as of February 18, 2015.

#NBA获胜概率

这个目录包含了这个故事背后的数据[每一个NBA球队在每场比赛中每分钟获胜的机会](https://fivethirty8.com/features/every-nba-teams-chance-of-winning-in-every-minute-cross-every-game/).

`nba.tsv公司`包含截至2015年2月18日，每支球队在一场比赛中的2014-15赛季获胜概率。
